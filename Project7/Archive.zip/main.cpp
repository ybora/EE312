#include "Project7.h"

using namespace std;

int main() {
	printf("Test\n");  
	set_input("test_grader.blip");  
	run();  
}